import '../../core/models/category_model.dart';

class CategoryRepository {
  const CategoryRepository();

  List<CategoryModel> loadCategories() {
    return const [
      CategoryModel(
        id: 'general-knowledge',
        title: 'General Knowledge',
        description: 'Wide-ranging questions for quick mental sparks.',
        icon: 'psychology_alt_rounded',
        questionCount: 3,
      ),
      CategoryModel(
        id: 'science',
        title: 'Science',
        description: 'Explore discoveries, systems, and the natural world.',
        icon: 'science_rounded',
        questionCount: 1,
      ),
      CategoryModel(
        id: 'technology',
        title: 'Technology',
        description: 'Dive into tools, systems, and modern innovation.',
        icon: 'computer_rounded',
        questionCount: 1,
      ),
      CategoryModel(
        id: 'cars',
        title: 'Cars',
        description: 'Speed through questions about machines and motion.',
        icon: 'directions_car_rounded',
        questionCount: 0,
      ),
      CategoryModel(
        id: 'space',
        title: 'Space',
        description: 'Journey through planets, stars, and the unknown.',
        icon: 'rocket_launch_rounded',
        questionCount: 0,
      ),
      CategoryModel(
        id: 'history',
        title: 'History',
        description: 'Revisit moments that shaped the world.',
        icon: 'history_edu_rounded',
        questionCount: 0,
      ),
      CategoryModel(
        id: 'sports',
        title: 'Sports',
        description: 'Take on fast-paced challenges from the arena.',
        icon: 'sports_esports_rounded',
        questionCount: 0,
      ),
      CategoryModel(
        id: 'programming',
        title: 'Programming',
        description: 'Test your logic in a code-inspired arena.',
        icon: 'code_rounded',
        questionCount: 0,
      ),
    ];
  }
}

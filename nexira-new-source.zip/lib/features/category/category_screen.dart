import 'package:flutter/material.dart';

import '../../core/models/category_model.dart';
import '../../routes/app_routes.dart';
import '../../shared/theme/colors.dart';
import '../../shared/theme/spacing.dart';
import '../../shared/theme/typography.dart';
import '../../shared/widgets/app_background.dart';
import '../../shared/widgets/glass_card.dart';
import 'category_repository.dart';

class CategoryScreen extends StatefulWidget {
  const CategoryScreen({super.key});

  @override
  State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final List<Animation<double>> _cardAnimations;

  final CategoryRepository _categoryRepository = const CategoryRepository();
  late final List<CategoryModel> _categories;

  @override
  void initState() {
    super.initState();
    _categories = _categoryRepository.loadCategories();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _cardAnimations = List.generate(
      _categories.length,
      (index) => CurvedAnimation(
        parent: _controller,
        curve: Interval(0.06 * index, 0.4 + (0.07 * index), curve: Curves.easeOutCubic),
      ).drive(Tween<double>(begin: 0.92, end: 1.0)),
    );
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isCompact = MediaQuery.sizeOf(context).width < 640;

    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(
              horizontal: isCompact ? NexiraSpacing.l : NexiraSpacing.xl,
              vertical: NexiraSpacing.l,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _Header(),
                SizedBox(height: NexiraSpacing.xl),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: isCompact ? 1 : 2,
                    crossAxisSpacing: NexiraSpacing.m,
                    mainAxisSpacing: NexiraSpacing.m,
                    childAspectRatio: 1.16,
                  ),
                  itemCount: _categories.length,
                  itemBuilder: (context, index) {
                    final item = _categories[index];
                    final animation = _cardAnimations[index];
                    return AnimatedBuilder(
                      animation: _controller,
                      builder: (context, _) {
                        return Transform.scale(
                          scale: animation.value,
                          child: Opacity(
                            opacity: animation.value,
                            child: _CategoryCard(
                              category: item,
                              onTap: () {
                                Navigator.of(context).pushNamed(
                                  AppRoutes.battle,
                                  arguments: item.id,
                                );
                              },
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Choose Your Challenge',
          style: NexiraTypography.headline.copyWith(color: NexiraColors.textPrimary),
        ),
        const SizedBox(height: NexiraSpacing.s),
        Text(
          'Select a category and start your battle',
          style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary),
        ),
      ],
    );
  }
}

class _CategoryCard extends StatelessWidget {
  const _CategoryCard({
    required this.category,
    required this.onTap,
  });

  final CategoryModel category;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: GlassCard(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _colorForCategory(category).withOpacity(0.18),
                border: Border.all(color: _colorForCategory(category).withOpacity(0.35), width: 1.1),
              ),
              alignment: Alignment.center,
              child: Icon(
                _iconFromName(category.icon),
                color: _colorForCategory(category),
                size: 24,
              ),
            ),
            const SizedBox(height: NexiraSpacing.m),
            Text(
              category.title,
              style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary),
            ),
            const SizedBox(height: NexiraSpacing.xs),
            Text(
              category.description,
              style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}

IconData _iconFromName(String name) {
  switch (name) {
    case 'psychology_alt_rounded':
      return Icons.psychology_alt_rounded;
    case 'science_rounded':
      return Icons.science_rounded;
    case 'computer_rounded':
      return Icons.computer_rounded;
    case 'directions_car_rounded':
      return Icons.directions_car_rounded;
    case 'rocket_launch_rounded':
      return Icons.rocket_launch_rounded;
    case 'history_edu_rounded':
      return Icons.history_edu_rounded;
    case 'sports_esports_rounded':
      return Icons.sports_esports_rounded;
    case 'code_rounded':
      return Icons.code_rounded;
    default:
      return Icons.help_outline;
  }
}

Color _colorForCategory(CategoryModel category) {
  switch (category.id) {
    case 'general-knowledge':
      return NexiraColors.primary;
    case 'science':
      return NexiraColors.accent;
    case 'technology':
      return NexiraColors.success;
    case 'cars':
      return NexiraColors.warning;
    case 'space':
      return NexiraColors.danger;
    case 'history':
      return NexiraColors.primary;
    case 'sports':
      return NexiraColors.accent;
    case 'programming':
      return NexiraColors.success;
    default:
      return NexiraColors.primary;
  }
}

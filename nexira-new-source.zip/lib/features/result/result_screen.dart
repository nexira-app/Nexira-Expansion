import 'package:flutter/material.dart';

import '../../routes/app_routes.dart';
import '../../shared/theme/colors.dart';
import '../../shared/theme/radius.dart';
import '../../shared/theme/spacing.dart';
import '../../shared/theme/typography.dart';
import '../../shared/widgets/app_background.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/neon_button.dart';

class ResultScreen extends StatefulWidget {
  const ResultScreen({super.key, this.categoryId});

  final String? categoryId;

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<double> _scale;
  late final Animation<double> _xpGlow;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _fade = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    ).drive(Tween<double>(begin: 0.0, end: 1.0));
    _scale = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.0, 0.7, curve: Curves.easeOutBack),
    ).drive(Tween<double>(begin: 0.9, end: 1.0));
    _xpGlow = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.35, 1.0, curve: Curves.easeOutCubic),
    ).drive(Tween<double>(begin: 0.72, end: 1.0));
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isCompact = MediaQuery.sizeOf(context).width < 640;
    final args = ModalRoute.of(context)?.settings.arguments;
    final resultData = args is Map<String, dynamic> ? args : <String, dynamic>{};
    final score = resultData['score'] as int? ?? 0;
    final correctAnswers = resultData['correctAnswers'] as int? ?? 0;
    final wrongAnswers = resultData['wrongAnswers'] as int? ?? 0;
    final xp = resultData['xp'] as int? ?? 0;
    final accuracy = correctAnswers + wrongAnswers == 0
        ? 0
        : ((correctAnswers / (correctAnswers + wrongAnswers)) * 100).round();

    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(
              horizontal: isCompact ? NexiraSpacing.l : NexiraSpacing.xl,
              vertical: NexiraSpacing.l,
            ),
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, _) {
                return Opacity(
                  opacity: _fade.value,
                  child: Transform.scale(
                    scale: _scale.value,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ResultHeader(),
                        SizedBox(height: NexiraSpacing.xl),
                        ScoreCard(
                          score: score,
                          correctAnswers: correctAnswers,
                          wrongAnswers: wrongAnswers,
                          accuracy: accuracy,
                        ),
                        SizedBox(height: NexiraSpacing.l),
                        XPRewardCard(glow: _xpGlow.value, xp: xp),
                        SizedBox(height: NexiraSpacing.l),
                        ActionButtons(categoryId: widget.categoryId),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}

class ResultHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Challenge Complete',
          style: NexiraTypography.headline.copyWith(color: NexiraColors.textPrimary),
        ),
        const SizedBox(height: NexiraSpacing.s),
        Text(
          'Your run has been sealed in neon light',
          style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary),
        ),
      ],
    );
  }
}

class ScoreCard extends StatelessWidget {
  const ScoreCard({
    required this.score,
    required this.correctAnswers,
    required this.wrongAnswers,
    required this.accuracy,
  });

  final int score;
  final int correctAnswers;
  final int wrongAnswers;
  final int accuracy;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Performance Snapshot',
            style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary),
          ),
          const SizedBox(height: NexiraSpacing.l),
          Row(
            children: [
              Expanded(child: _MetricTile(label: 'Score', value: '$score')),
              const SizedBox(width: NexiraSpacing.m),
              Expanded(child: _MetricTile(label: 'Accuracy', value: '$accuracy%')),
            ],
          ),
          const SizedBox(height: NexiraSpacing.m),
          _MetricTile(label: 'Correct', value: '$correctAnswers'),
          const SizedBox(height: NexiraSpacing.m),
          _MetricTile(label: 'Wrong', value: '$wrongAnswers'),
        ],
      ),
    );
  }
}

class _MetricTile extends StatelessWidget {
  const _MetricTile({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
      decoration: BoxDecoration(
        color: NexiraColors.surface.withOpacity(0.72),
        borderRadius: NexiraRadius.medium as BorderRadius?,
        border: Border.all(color: NexiraColors.border, width: 1.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: NexiraTypography.caption.copyWith(color: NexiraColors.textSecondary)),
          const SizedBox(height: 4),
          Text(value, style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary)),
        ],
      ),
    );
  }
}

class XPRewardCard extends StatelessWidget {
  const XPRewardCard({required this.glow, required this.xp});

  final double glow;
  final int xp;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          Transform.scale(
            scale: glow,
            child: Container(
              width: 92,
              height: 92,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [NexiraColors.primary, NexiraColors.accent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: NexiraColors.accent.withOpacity(0.28),
                    blurRadius: 24,
                    spreadRadius: 2,
                  ),
                ],
              ),
              alignment: Alignment.center,
              child: Text(
                '+XP',
                style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary),
              ),
            ),
          ),
          const SizedBox(height: NexiraSpacing.m),
          Text(
            '$xp XP Reward Ready',
            style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary),
          ),
          const SizedBox(height: NexiraSpacing.xs),
          Text(
            'This reward state is a placeholder for the future progression system.',
            style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class ActionButtons extends StatelessWidget {
  const ActionButtons({this.categoryId});

  final String? categoryId;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        NeonButton(
          onPressed: () {
            Navigator.of(context).pushNamed(
              AppRoutes.battle,
              arguments: categoryId,
            );
          },
          isFullWidth: true,
          child: Text('Play Again', style: NexiraTypography.label),
        ),
        const SizedBox(height: NexiraSpacing.m),
        NeonButton(
          onPressed: () {
            Navigator.of(context).pushNamedAndRemoveUntil(
              AppRoutes.home,
              (route) => false,
            );
          },
          isFullWidth: true,
          child: Text('Back To Home', style: NexiraTypography.label),
        ),
      ],
    );
  }
}

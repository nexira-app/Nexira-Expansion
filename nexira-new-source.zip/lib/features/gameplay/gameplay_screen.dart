import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/models/question_model.dart';
import '../../routes/app_routes.dart';
import '../../services/question_repository.dart';
import '../../services/storage/local_storage_service.dart';
import '../../shared/theme/colors.dart';
import '../../shared/theme/radius.dart';
import '../../shared/theme/spacing.dart';
import '../../shared/theme/typography.dart';
import '../../shared/widgets/app_background.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/loading_view.dart';
import 'game_controller.dart';

class GameplayScreen extends StatefulWidget {
  const GameplayScreen({super.key, this.categoryId});

  final String? categoryId;

  @override
  State<GameplayScreen> createState() => _GameplayScreenState();
}

class _GameplayScreenState extends State<GameplayScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _cardAnimation;
  late final Animation<double> _buttonsAnimation;

  GameController? _gameController;
  int _selectedIndex = -1;
  bool _isInitializing = true;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _cardAnimation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    ).drive(Tween<double>(begin: 0.94, end: 1.0));
    _buttonsAnimation = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.25, 0.9, curve: Curves.easeOutCubic),
    ).drive(Tween<double>(begin: 0.8, end: 1.0));
    _controller.forward();
    _initializeGame();
  }

  @override
  void dispose() {
    _controller.dispose();
    _gameController?.removeListener(_handleControllerChanged);
    super.dispose();
  }

  Future<void> _initializeGame() async {
    final prefs = await SharedPreferences.getInstance();
    final controller = GameController(
      questionRepository: QuestionRepository(),
      storageService: SharedPreferencesLocalStorageService(prefs),
    );
    controller.addListener(_handleControllerChanged);
    await controller.startGame(categoryId: widget.categoryId ?? 'general-knowledge');
    if (mounted) {
      setState(() {
        _gameController = controller;
        _isInitializing = false;
      });
    }
  }

  void _handleControllerChanged() {
    if (mounted) {
      setState(() {});
    }
  }

  Future<void> _handleAnswerSelection(int index) async {
    final controller = _gameController;
    if (controller == null) {
      return;
    }

    setState(() {
      _selectedIndex = index;
    });

    await controller.submitAnswer(index);

    if (!mounted) {
      return;
    }

    if (controller.state?.isComplete == true) {
      final resultArguments = <String, dynamic>{
        'categoryId': widget.categoryId,
        'score': controller.state?.score ?? 0,
        'correctAnswers': controller.state?.correctAnswers ?? 0,
        'wrongAnswers': controller.state?.wrongAnswers ?? 0,
        'xp': controller.state?.score ?? 0,
      };
      Navigator.of(context).pushReplacementNamed(
        AppRoutes.result,
        arguments: resultArguments,
      );
      return;
    }

    setState(() {
      _selectedIndex = -1;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isCompact = MediaQuery.sizeOf(context).width < 640;
    final controller = _gameController;
    final state = controller?.state;

    if (_isInitializing || controller == null || state == null) {
      return Scaffold(
        body: AppBackground(
          child: LoadingView(message: 'Loading challenge arena...'),
        ),
      );
    }

    final question = state.currentQuestion;
    if (question == null) {
      return Scaffold(
        body: AppBackground(
          child: LoadingView(message: 'Preparing your next challenge...'),
        ),
      );
    }

    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(
              horizontal: isCompact ? NexiraSpacing.l : NexiraSpacing.xl,
              vertical: NexiraSpacing.l,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GameHeader(
                  category: widget.categoryId ?? 'Challenge',
                  score: state.score.toString(),
                  questionNumber: state.currentQuestionIndex + 1,
                ),
                SizedBox(height: NexiraSpacing.xl),
                AnimatedBuilder(
                  animation: _controller,
                  builder: (context, _) {
                    return Transform.scale(
                      scale: _cardAnimation.value,
                      child: Opacity(
                        opacity: _cardAnimation.value,
                        child: QuestionCard(question: question),
                      ),
                    );
                  },
                ),
                SizedBox(height: NexiraSpacing.l),
                AnimatedBuilder(
                  animation: _controller,
                  builder: (context, _) {
                    return Transform.translate(
                      offset: Offset(0, 18 * (1 - _buttonsAnimation.value)),
                      child: Opacity(
                        opacity: _buttonsAnimation.value,
                        child: AnswerArea(
                          selectedIndex: _selectedIndex,
                          options: question.answers,
                          onSelect: _handleAnswerSelection,
                        ),
                      ),
                    );
                  },
                ),
                SizedBox(height: NexiraSpacing.l),
                FeedbackArea(
                  correctAnswers: state.correctAnswers,
                  wrongAnswers: state.wrongAnswers,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class GameHeader extends StatelessWidget {
  const GameHeader({
    required this.category,
    required this.score,
    required this.questionNumber,
  });

  final String category;
  final String score;
  final int questionNumber;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  category,
                  style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary),
                ),
                const SizedBox(height: NexiraSpacing.xs),
                Text(
                  'Arena Ready',
                  style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary),
                ),
              ],
            ),
          ),
          _StatChip(label: 'Score', value: score),
          const SizedBox(width: NexiraSpacing.s),
          _StatChip(label: 'Q', value: '$questionNumber'),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  const _StatChip({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: NexiraColors.surface.withOpacity(0.7),
        borderRadius: NexiraRadius.medium as BorderRadius?,
        border: Border.all(color: NexiraColors.border, width: 1.0),
      ),
      child: Column(
        children: [
          Text(label, style: NexiraTypography.caption.copyWith(color: NexiraColors.textSecondary)),
          const SizedBox(height: 2),
          Text(value, style: NexiraTypography.label.copyWith(color: NexiraColors.textPrimary)),
        ],
      ),
    );
  }
}

class QuestionCard extends StatelessWidget {
  const QuestionCard({required this.question});

  final QuestionModel question;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Question ${question.id}',
            style: NexiraTypography.caption.copyWith(color: NexiraColors.accent),
          ),
          const SizedBox(height: NexiraSpacing.s),
          Text(
            question.questionText,
            style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary),
          ),
          const SizedBox(height: NexiraSpacing.m),
          Text(
            'Local challenge ready',
            style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary),
          ),
        ],
      ),
    );
  }
}

class AnswerArea extends StatelessWidget {
  const AnswerArea({
    required this.selectedIndex,
    required this.options,
    required this.onSelect,
  });

  final int selectedIndex;
  final List<String> options;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(options.length, (index) {
        final option = options[index];
        final isSelected = selectedIndex == index;
        return Padding(
          padding: EdgeInsets.only(bottom: index == options.length - 1 ? 0 : NexiraSpacing.s),
          child: AnswerButton(
            label: String.fromCharCode(65 + index),
            text: option,
            isSelected: isSelected,
            state: isSelected ? AnswerButtonState.selected : AnswerButtonState.normal,
            onPressed: () => onSelect(index),
          ),
        );
      }),
    );
  }
}

class AnswerButton extends StatelessWidget {
  const AnswerButton({
    required this.label,
    required this.text,
    required this.isSelected,
    required this.state,
    required this.onPressed,
  });

  final String label;
  final String text;
  final bool isSelected;
  final AnswerButtonState state;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final isActive = state == AnswerButtonState.selected;
    final borderColor = isActive ? NexiraColors.accent : NexiraColors.border;
    final backgroundColor = isActive ? NexiraColors.surface.withOpacity(0.95) : NexiraColors.surface.withOpacity(0.65);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onPressed,
        borderRadius: NexiraRadius.medium as BorderRadius?,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: NexiraRadius.medium,
            border: Border.all(color: borderColor, width: 1.2),
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: NexiraColors.accent.withOpacity(0.22),
                      blurRadius: 12,
                      spreadRadius: 0,
                    ),
                  ]
                : null,
          ),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isActive ? NexiraColors.accent.withOpacity(0.14) : NexiraColors.surface.withOpacity(0.8),
                  border: Border.all(color: isActive ? NexiraColors.accent : NexiraColors.border, width: 1.0),
                ),
                child: Text(label, style: NexiraTypography.label.copyWith(color: NexiraColors.textPrimary)),
              ),
              const SizedBox(width: NexiraSpacing.m),
              Expanded(
                child: Text(text, style: NexiraTypography.body.copyWith(color: NexiraColors.textPrimary)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

enum AnswerButtonState { normal, selected, correct, wrong }

class FeedbackArea extends StatelessWidget {
  const FeedbackArea({required this.correctAnswers, required this.wrongAnswers});

  final int correctAnswers;
  final int wrongAnswers;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Live Feedback',
            style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary),
          ),
          const SizedBox(height: NexiraSpacing.xs),
          Text(
            'Correct: $correctAnswers • Wrong: $wrongAnswers',
            style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary),
          ),
        ],
      ),
    );
  }
}

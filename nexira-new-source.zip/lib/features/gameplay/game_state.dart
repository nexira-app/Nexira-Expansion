import '../../core/models/question_model.dart';

class GameState {
  const GameState({
    required this.currentQuestionIndex,
    required this.questions,
    required this.selectedAnswer,
    required this.score,
    required this.correctAnswers,
    required this.wrongAnswers,
    required this.startTime,
  });

  final int currentQuestionIndex;
  final List<QuestionModel> questions;
  final String? selectedAnswer;
  final int score;
  final int correctAnswers;
  final int wrongAnswers;
  final DateTime startTime;

  bool get isComplete => currentQuestionIndex >= questions.length;

  QuestionModel? get currentQuestion =>
      questions.isEmpty ? null : questions[currentQuestionIndex];

  int get questionCount => questions.length;

  int get answeredCount => correctAnswers + wrongAnswers;

  GameState copyWith({
    int? currentQuestionIndex,
    List<QuestionModel>? questions,
    String? selectedAnswer,
    int? score,
    int? correctAnswers,
    int? wrongAnswers,
    DateTime? startTime,
  }) {
    return GameState(
      currentQuestionIndex: currentQuestionIndex ?? this.currentQuestionIndex,
      questions: questions ?? this.questions,
      selectedAnswer: selectedAnswer ?? this.selectedAnswer,
      score: score ?? this.score,
      correctAnswers: correctAnswers ?? this.correctAnswers,
      wrongAnswers: wrongAnswers ?? this.wrongAnswers,
      startTime: startTime ?? this.startTime,
    );
  }
}

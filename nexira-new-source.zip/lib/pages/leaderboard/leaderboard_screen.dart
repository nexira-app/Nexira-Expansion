import 'package:flutter/material.dart';

import '../../shared/theme/colors.dart';
import '../../shared/theme/spacing.dart';
import '../../shared/theme/typography.dart';
import '../../shared/widgets/app_background.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/neon_app_bar.dart';

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final leaderboard = <_LeaderboardEntry>[
      _LeaderboardEntry(rank: 1, name: 'Nova', level: 18, xp: 18200, avatar: 'N'),
      _LeaderboardEntry(rank: 2, name: 'Astra', level: 16, xp: 16850, avatar: 'A'),
      _LeaderboardEntry(rank: 3, name: 'Zero', level: 15, xp: 15420, avatar: 'Z'),
      _LeaderboardEntry(rank: 4, name: 'Rift', level: 14, xp: 14980, avatar: 'R'),
      _LeaderboardEntry(rank: 5, name: 'Lumen', level: 13, xp: 14240, avatar: 'L'),
    ];

    return Scaffold(
      appBar: const NeonAppBar(title: Text('Leaderboard')),
      body: AppBackground(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(NexiraSpacing.l),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Leaderboard',
                      style: NexiraTypography.headline.copyWith(color: NexiraColors.textPrimary),
                    ),
                    const SizedBox(height: NexiraSpacing.s),
                    Text(
                      'Local rankings that keep your competitive streak visible.',
                      style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary),
                    ),
                    const SizedBox(height: NexiraSpacing.xl),
                    GlassCard(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Current Rank', style: NexiraTypography.label.copyWith(color: NexiraColors.textSecondary)),
                              Text('#7', style: NexiraTypography.title.copyWith(color: NexiraColors.accent)),
                            ],
                          ),
                          const SizedBox(height: NexiraSpacing.s),
                          Row(
                            children: [
                              Container(
                                width: 56,
                                height: 56,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    colors: [NexiraColors.primary, NexiraColors.accent],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                ),
                                alignment: Alignment.center,
                                child: Text('G', style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary)),
                              ),
                              const SizedBox(width: NexiraSpacing.m),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Guest Player', style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary)),
                                    const SizedBox(height: NexiraSpacing.xs),
                                    Text('Level 12 • 2840 XP', style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary)),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: NexiraSpacing.l),
                    GlassCard(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                      child: TabBar(
                        controller: _tabController,
                        labelColor: NexiraColors.textPrimary,
                        unselectedLabelColor: NexiraColors.textSecondary,
                        indicator: BoxDecoration(
                          color: NexiraColors.surfaceElevated,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        tabs: const [
                          Tab(text: 'Weekly'),
                          Tab(text: 'All Time'),
                        ],
                      ),
                    ),
                    const SizedBox(height: NexiraSpacing.m),
                    ...leaderboard.map((entry) => _LeaderboardTile(entry: entry)).toList(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LeaderboardTile extends StatelessWidget {
  const _LeaderboardTile({required this.entry});

  final _LeaderboardEntry entry;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: NexiraSpacing.m),
      child: GlassCard(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: NexiraColors.surfaceElevated,
                borderRadius: BorderRadius.circular(999),
              ),
              alignment: Alignment.center,
              child: Text('#${entry.rank}', style: NexiraTypography.label.copyWith(color: NexiraColors.accent)),
            ),
            const SizedBox(width: NexiraSpacing.m),
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [NexiraColors.primary, NexiraColors.accent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              alignment: Alignment.center,
              child: Text(entry.avatar, style: NexiraTypography.label.copyWith(color: NexiraColors.textPrimary)),
            ),
            const SizedBox(width: NexiraSpacing.m),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(entry.name, style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary)),
                  const SizedBox(height: NexiraSpacing.xs),
                  Text('Level ${entry.level}', style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary)),
                ],
              ),
            ),
            Text('${entry.xp} XP', style: NexiraTypography.label.copyWith(color: NexiraColors.textPrimary)),
          ],
        ),
      ),
    );
  }
}

class _LeaderboardEntry {
  const _LeaderboardEntry({required this.rank, required this.name, required this.level, required this.xp, required this.avatar});

  final int rank;
  final String name;
  final int level;
  final int xp;
  final String avatar;
}

import 'package:flutter/material.dart';

import '../shared/theme/colors.dart';
import '../shared/theme/spacing.dart';
import '../shared/theme/typography.dart';
import '../shared/widgets/app_background.dart';
import '../shared/widgets/glass_card.dart';

class PlaceholderPage extends StatelessWidget {
  const PlaceholderPage({
    super.key,
    required this.title,
    this.subtitle,
  });

  final String title;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AppBackground(
        child: Center(
          child: GlassCard(
            width: 320,
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary),
                  textAlign: TextAlign.center,
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: NexiraSpacing.s),
                  Text(
                    subtitle!,
                    style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary),
                    textAlign: TextAlign.center,
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

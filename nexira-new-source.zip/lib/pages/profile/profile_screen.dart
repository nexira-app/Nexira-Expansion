import 'package:flutter/material.dart';

import '../../core/models/player_profile_model.dart';
import '../../shared/theme/colors.dart';
import '../../shared/theme/spacing.dart';
import '../../shared/theme/typography.dart';
import '../../shared/widgets/app_background.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/neon_app_bar.dart';
import '../../shared/widgets/neon_button.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final profile = PlayerProfileModel(
      id: 'guest-01',
      displayName: 'Guest Player',
      avatar: 'GP',
      xp: 2840,
      level: 12,
      gamesPlayed: 38,
      createdAt: DateTime.now().subtract(const Duration(days: 45)),
    );

    final screenWidth = MediaQuery.sizeOf(context).width;
    final isCompact = screenWidth < 640;
    final spacing = NexiraSpacing.m;
    final xpProgress = (profile.xp % 1000) / 1000;

    return Scaffold(
      appBar: const NeonAppBar(title: Text('Profile')),
      body: AppBackground(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: isCompact ? NexiraSpacing.l : NexiraSpacing.xl,
            vertical: NexiraSpacing.l,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Player Profile',
                style: NexiraTypography.headline.copyWith(color: NexiraColors.textPrimary),
              ),
              const SizedBox(height: NexiraSpacing.s),
              Text(
                'A premium view of your progress, momentum, and streaks.',
                style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary),
              ),
              SizedBox(height: spacing * 1.5),
              GlassCard(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    Container(
                      width: 92,
                      height: 92,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [NexiraColors.primary, NexiraColors.accent],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        profile.avatar,
                        style: NexiraTypography.headline.copyWith(color: NexiraColors.textPrimary),
                      ),
                    ),
                    const SizedBox(height: NexiraSpacing.m),
                    Text(
                      profile.displayName,
                      style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary),
                    ),
                    const SizedBox(height: NexiraSpacing.xs),
                    Text(
                      'Current Level ${profile.level}',
                      style: NexiraTypography.body.copyWith(color: NexiraColors.accent),
                    ),
                    const SizedBox(height: NexiraSpacing.l),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('XP Progress', style: NexiraTypography.label.copyWith(color: NexiraColors.textSecondary)),
                            Text('${(xpProgress * 100).round()}%', style: NexiraTypography.label.copyWith(color: NexiraColors.textPrimary)),
                          ],
                        ),
                        const SizedBox(height: NexiraSpacing.s),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(999),
                          child: LinearProgressIndicator(
                            value: xpProgress.clamp(0.0, 1.0),
                            minHeight: 10,
                            backgroundColor: NexiraColors.border.withOpacity(0.4),
                            color: NexiraColors.accent,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: spacing * 1.5),
              Wrap(
                spacing: spacing,
                runSpacing: spacing,
                children: [
                  _StatTile(label: 'Games Played', value: profile.gamesPlayed.toString(), accent: NexiraColors.primary),
                  _StatTile(label: 'Total XP', value: '${profile.xp}', accent: NexiraColors.accent),
                  _StatTile(label: 'Accuracy', value: '86.4%', accent: NexiraColors.success),
                  _StatTile(label: 'Wins', value: '24', accent: NexiraColors.warning),
                  _StatTile(label: 'Completed Challenges', value: '17', accent: NexiraColors.danger),
                ],
              ),
              SizedBox(height: spacing * 1.5),
              _ActionRow(
                onCreateAccount: () => _showPlaceholder(context, 'Create Account'),
                onSignIn: () => _showPlaceholder(context, 'Sign In'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showPlaceholder(BuildContext context, String label) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$label flow coming soon.')),
    );
  }
}

class _StatTile extends StatelessWidget {
  const _StatTile({required this.label, required this.value, required this.accent});

  final String label;
  final String value;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 160,
      child: GlassCard(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 42,
              height: 4,
              decoration: BoxDecoration(
                color: accent,
                borderRadius: BorderRadius.circular(999),
              ),
            ),
            const SizedBox(height: NexiraSpacing.s),
            Text(value, style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary)),
            const SizedBox(height: NexiraSpacing.xs),
            Text(label, style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary)),
          ],
        ),
      ),
    );
  }
}

class _ActionRow extends StatelessWidget {
  const _ActionRow({required this.onCreateAccount, required this.onSignIn});

  final VoidCallback onCreateAccount;
  final VoidCallback onSignIn;

  @override
  Widget build(BuildContext context) {
    final isCompact = MediaQuery.sizeOf(context).width < 640;

    return Column(
      children: [
        if (!isCompact)
          Row(
            children: [
              Expanded(
                child: NeonButton(
                  onPressed: onCreateAccount,
                  child: Text('Create Account', style: NexiraTypography.label),
                ),
              ),
              const SizedBox(width: NexiraSpacing.m),
              Expanded(
                child: NeonButton(
                  onPressed: onSignIn,
                  child: Text('Sign In', style: NexiraTypography.label),
                ),
              ),
            ],
          )
        else ...[
          NeonButton(
            onPressed: onCreateAccount,
            isFullWidth: true,
            child: Text('Create Account', style: NexiraTypography.label),
          ),
          const SizedBox(height: NexiraSpacing.m),
          NeonButton(
            onPressed: onSignIn,
            isFullWidth: true,
            child: Text('Sign In', style: NexiraTypography.label),
          ),
        ],
      ],
    );
  }
}

import 'package:flutter/material.dart';

import '../../shared/theme/colors.dart';
import '../../shared/theme/spacing.dart';
import '../../shared/theme/typography.dart';
import '../../shared/widgets/app_background.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/neon_app_bar.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool musicEnabled = true;
  bool soundEffectsEnabled = true;
  bool vibrationEnabled = true;
  bool notificationsEnabled = false;

  @override
  Widget build(BuildContext context) {
    final settingsItems = <_SettingsItem>[
      _SettingsItem(title: 'Language', subtitle: 'English', trailing: const Icon(Icons.chevron_right_rounded)),
      _SettingsItem(
        title: 'Music',
        subtitle: 'Background audio',
        trailing: Switch(
          value: musicEnabled,
          onChanged: (value) => setState(() => musicEnabled = value),
          activeColor: NexiraColors.accent,
        ),
      ),
      _SettingsItem(
        title: 'Sound Effects',
        subtitle: 'SFX for interactions',
        trailing: Switch(
          value: soundEffectsEnabled,
          onChanged: (value) => setState(() => soundEffectsEnabled = value),
          activeColor: NexiraColors.accent,
        ),
      ),
      _SettingsItem(
        title: 'Vibration',
        subtitle: 'Haptic feedback',
        trailing: Switch(
          value: vibrationEnabled,
          onChanged: (value) => setState(() => vibrationEnabled = value),
          activeColor: NexiraColors.accent,
        ),
      ),
      _SettingsItem(
        title: 'Notifications',
        subtitle: 'Daily reminders',
        trailing: Switch(
          value: notificationsEnabled,
          onChanged: (value) => setState(() => notificationsEnabled = value),
          activeColor: NexiraColors.accent,
        ),
      ),
      _SettingsItem(title: 'Privacy Policy', subtitle: 'View data handling details', trailing: const Icon(Icons.chevron_right_rounded)),
      _SettingsItem(title: 'Terms of Service', subtitle: 'Review user terms', trailing: const Icon(Icons.chevron_right_rounded)),
      _SettingsItem(title: 'About Nexira', subtitle: 'Learn more about the app', trailing: const Icon(Icons.chevron_right_rounded)),
      _SettingsItem(title: 'App Version', subtitle: '1.0.0 • Build 1', trailing: const SizedBox.shrink()),
    ];

    return Scaffold(
      appBar: const NeonAppBar(title: Text('Settings')),
      body: AppBackground(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(NexiraSpacing.l),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Settings',
                style: NexiraTypography.headline.copyWith(color: NexiraColors.textPrimary),
              ),
              const SizedBox(height: NexiraSpacing.s),
              Text(
                'Fine-tune your experience with a polished control center.',
                style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary),
              ),
              const SizedBox(height: NexiraSpacing.l),
              GlassCard(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Column(
                  children: settingsItems.map((item) => _SettingsRow(item: item)).toList(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SettingsRow extends StatelessWidget {
  const _SettingsRow({required this.item});

  final _SettingsItem item;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      title: Text(item.title, style: NexiraTypography.title.copyWith(color: NexiraColors.textPrimary, fontSize: 18)),
      subtitle: Text(item.subtitle, style: NexiraTypography.body.copyWith(color: NexiraColors.textSecondary)),
      trailing: item.trailing,
      onTap: () {},
    );
  }
}

class _SettingsItem {
  const _SettingsItem({required this.title, required this.subtitle, required this.trailing});

  final String title;
  final String subtitle;
  final Widget trailing;
}

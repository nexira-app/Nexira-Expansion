import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../theme/colors.dart';
import '../theme/radius.dart';
import '../theme/spacing.dart';
import '../theme/typography.dart';

class ErrorView extends StatelessWidget {
  const ErrorView({
    super.key,
    this.title,
    this.message,
    this.action,
    this.icon,
  });

  final String? title;
  final String? message;
  final Widget? action;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final themeExtension = Theme.of(context).extension<NexiraThemeData>();
    final surfaceColor = themeExtension?.surfaceColor ?? NexiraColors.surface;
    final borderColor = themeExtension?.borderColor ?? NexiraColors.border;
    final textColor = themeExtension?.textPrimaryColor ?? NexiraColors.textPrimary;
    final secondaryColor = themeExtension?.textSecondaryColor ?? NexiraColors.textSecondary;
    final radius = themeExtension?.radius ?? NexiraRadius.large;
    final spacing = themeExtension?.spacing ?? NexiraSpacing.m;

    return Center(
      child: Container(
        margin: EdgeInsets.all(spacing),
        padding: EdgeInsets.all(spacing * 1.5),
        decoration: BoxDecoration(
          color: surfaceColor.withOpacity(0.9),
          borderRadius: radius,
          border: Border.all(color: borderColor, width: 1.1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon ?? Icons.error_outline_rounded,
              color: NexiraColors.danger,
              size: 32,
            ),
            SizedBox(height: spacing),
            Text(
              title ?? 'Something went wrong',
              style: NexiraTypography.title.copyWith(color: textColor),
              textAlign: TextAlign.center,
            ),
            if (message != null) ...[
              SizedBox(height: spacing * 0.5),
              Text(
                message!,
                style: NexiraTypography.body.copyWith(color: secondaryColor),
                textAlign: TextAlign.center,
              ),
            ],
            if (action != null) ...[
              SizedBox(height: spacing),
              action!,
            ],
          ],
        ),
      ),
    );
  }
}

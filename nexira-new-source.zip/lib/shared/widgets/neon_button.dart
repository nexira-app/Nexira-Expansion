import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../theme/colors.dart';
import '../theme/durations.dart';
import '../theme/radius.dart';
import '../theme/spacing.dart';
import '../theme/typography.dart';

class NeonButton extends StatelessWidget {
  const NeonButton({
    super.key,
    required this.child,
    this.onPressed,
    this.padding,
    this.borderRadius,
    this.minHeight,
    this.minWidth,
    this.isFullWidth = false,
  });

  final Widget child;
  final VoidCallback? onPressed;
  final EdgeInsetsGeometry? padding;
  final BorderRadiusGeometry? borderRadius;
  final double? minHeight;
  final double? minWidth;
  final bool isFullWidth;

  @override
  Widget build(BuildContext context) {
    final themeExtension = Theme.of(context).extension<NexiraThemeData>();
    final primaryColor = themeExtension?.primaryColor ?? NexiraColors.primary;
    final accentColor = themeExtension?.accentColor ?? NexiraColors.accent;
    final textColor = themeExtension?.textPrimaryColor ?? NexiraColors.textPrimary;
    final radius = borderRadius ?? themeExtension?.radius ?? NexiraRadius.medium;
    final spacing = themeExtension?.spacing ?? NexiraSpacing.m;

    final resolvedPadding = padding ?? EdgeInsets.symmetric(horizontal: spacing * 1.5, vertical: spacing * 0.75);

    return ConstrainedBox(
      constraints: BoxConstraints(
        minHeight: minHeight ?? 48,
        minWidth: isFullWidth ? double.infinity : minWidth ?? 0,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: radius as BorderRadius?,
          child: AnimatedContainer(
            duration: NexiraDurations.fast,
            alignment: Alignment.center,
            padding: resolvedPadding,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryColor, accentColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: radius,
              border: Border.all(color: accentColor.withOpacity(0.35), width: 1.1),
              boxShadow: [
                BoxShadow(
                  color: accentColor.withOpacity(0.24),
                  blurRadius: 16,
                  spreadRadius: 0,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: DefaultTextStyle(
              style: NexiraTypography.label.copyWith(color: textColor),
              child: child,
            ),
          ),
        ),
      ),
    );
  }
}

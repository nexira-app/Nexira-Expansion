import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../theme/colors.dart';
import '../theme/durations.dart';
import '../theme/spacing.dart';
import '../theme/typography.dart';

class LoadingView extends StatelessWidget {
  const LoadingView({
    super.key,
    this.message,
    this.size = 28,
    this.strokeWidth = 3,
  });

  final String? message;
  final double size;
  final double strokeWidth;

  @override
  Widget build(BuildContext context) {
    final themeExtension = Theme.of(context).extension<NexiraThemeData>();
    final primaryColor = themeExtension?.primaryColor ?? NexiraColors.primary;
    final accentColor = themeExtension?.accentColor ?? NexiraColors.accent;
    final textColor = themeExtension?.textSecondaryColor ?? NexiraColors.textSecondary;
    final spacing = themeExtension?.spacing ?? NexiraSpacing.m;

    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: size,
            height: size,
            child: CircularProgressIndicator(
              strokeWidth: strokeWidth,
              valueColor: AlwaysStoppedAnimation<Color>(accentColor),
              backgroundColor: primaryColor.withOpacity(0.2),
            ),
          ),
          if (message != null) ...[
            SizedBox(height: spacing),
            Text(
              message!,
              style: NexiraTypography.label.copyWith(color: textColor),
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../theme/colors.dart';
import '../theme/radius.dart';
import '../theme/spacing.dart';

class GlassCard extends StatelessWidget {
  const GlassCard({
    super.key,
    required this.child,
    this.padding,
    this.margin,
    this.borderRadius,
    this.width,
    this.height,
    this.onTap,
    this.borderColor,
    this.opacity = 0.85,
  });

  final Widget child;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final BorderRadiusGeometry? borderRadius;
  final double? width;
  final double? height;
  final VoidCallback? onTap;
  final Color? borderColor;
  final double opacity;

  @override
  Widget build(BuildContext context) {
    final themeExtension = Theme.of(context).extension<NexiraThemeData>();
    final surfaceColor = themeExtension?.surfaceColor ?? NexiraColors.surface;
    final borderColorValue = borderColor ?? themeExtension?.borderColor ?? NexiraColors.border;
    final radius = borderRadius ?? themeExtension?.radius ?? NexiraRadius.large;
    final spacing = themeExtension?.spacing ?? NexiraSpacing.m;
    final shadow = themeExtension?.shadow ?? const BoxShadow(color: Color(0x33050816), blurRadius: 20, offset: Offset(0, 8));

    final card = Container(
      width: width,
      height: height,
      margin: margin,
      padding: padding ?? EdgeInsets.all(spacing),
      decoration: BoxDecoration(
        color: surfaceColor.withOpacity(opacity),
        borderRadius: radius,
        border: Border.all(color: borderColorValue, width: 1.1),
        boxShadow: [shadow],
      ),
      child: child,
    );

    if (onTap == null) {
      return card;
    }

    return ClipRRect(
      borderRadius: radius,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: radius as BorderRadius?,
          child: card,
        ),
      ),
    );
  }
}

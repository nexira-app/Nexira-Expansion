import 'package:flutter/material.dart';

import '../theme/colors.dart';
import '../theme/durations.dart';
import '../theme/gradients.dart';
import '../theme/spacing.dart';
import '../theme/app_theme.dart';

class AppBackground extends StatelessWidget {
  const AppBackground({
    super.key,
    required this.child,
    this.padding,
    this.overlay,
    this.showDecorations = true,
  });

  final Widget child;
  final EdgeInsetsGeometry? padding;
  final Widget? overlay;
  final bool showDecorations;

  @override
  Widget build(BuildContext context) {
    final themeExtension = Theme.of(context).extension<NexiraThemeData>();
    final backgroundColor = themeExtension?.backgroundColor ?? NexiraColors.background;
    final surfaceColor = themeExtension?.surfaceColor ?? NexiraColors.surface;
    final primaryColor = themeExtension?.primaryColor ?? NexiraColors.primary;
    final accentColor = themeExtension?.accentColor ?? NexiraColors.accent;
    final spacing = themeExtension?.spacing ?? NexiraSpacing.m;

    return AnimatedContainer(
      duration: NexiraDurations.normal,
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [backgroundColor, surfaceColor, backgroundColor],
        ),
      ),
      child: Stack(
        children: [
          if (showDecorations) ...[
            Positioned(
              top: -40,
              left: -30,
              child: _DecorativeOrb(
                color: primaryColor.withOpacity(0.16),
                size: 220,
              ),
            ),
            Positioned(
              bottom: -60,
              right: -40,
              child: _DecorativeOrb(
                color: accentColor.withOpacity(0.14),
                size: 260,
              ),
            ),
          ],
          SafeArea(
            child: Padding(
              padding: padding ?? EdgeInsets.all(spacing),
              child: child,
            ),
          ),
          if (overlay != null) overlay!,
        ],
      ),
    );
  }
}

class _DecorativeOrb extends StatelessWidget {
  const _DecorativeOrb({required this.color, required this.size});

  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color, color.withOpacity(0.0)],
          stops: const [0.0, 1.0],
        ),
      ),
    );
  }
}

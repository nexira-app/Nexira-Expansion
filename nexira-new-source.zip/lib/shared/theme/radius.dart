import 'package:flutter/material.dart';

abstract final class NexiraRadius {
  static const double xs = 6.0;
  static const double s = 10.0;
  static const double m = 14.0;
  static const double l = 20.0;
  static const double xl = 28.0;
  static const double pill = 999.0;

  static const BorderRadius small = BorderRadius.all(Radius.circular(xs));
  static const BorderRadius medium = BorderRadius.all(Radius.circular(m));
  static const BorderRadius large = BorderRadius.all(Radius.circular(l));
  static const BorderRadius pillRadius = BorderRadius.all(Radius.circular(pill));
}

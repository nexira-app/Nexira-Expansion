import 'package:flutter/material.dart';
import 'dart:ui' show lerpDouble;

import 'animations.dart';
import 'colors.dart';
import 'gradients.dart';
import 'radius.dart';
import 'shadows.dart';
import 'spacing.dart';
import 'typography.dart';

class AppTheme {
  static ThemeData get dark {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: NexiraColors.background,
      colorScheme: const ColorScheme.dark(
        primary: NexiraColors.primary,
        secondary: NexiraColors.accent,
        surface: NexiraColors.surface,
        onSurface: NexiraColors.textPrimary,
        onPrimary: NexiraColors.textPrimary,
        error: NexiraColors.danger,
        tertiary: NexiraColors.success,
      ),
      textTheme: NexiraTypography.textTheme.apply(
        bodyColor: NexiraColors.textPrimary,
        displayColor: NexiraColors.textPrimary,
      ),
      cardTheme: CardThemeData(
        color: NexiraColors.surface,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: NexiraRadius.medium),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: NexiraColors.background,
        foregroundColor: NexiraColors.textPrimary,
        elevation: 0,
      ),
      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(
          borderRadius: NexiraRadius.medium,
          borderSide: const BorderSide(color: NexiraColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: NexiraRadius.medium,
          borderSide: const BorderSide(color: NexiraColors.accent, width: 1.5),
        ),
      ),
      extensions: <ThemeExtension<dynamic>>[
        NexiraThemeData(
          primaryColor: NexiraColors.primary,
          accentColor: NexiraColors.accent,
          successColor: NexiraColors.success,
          warningColor: NexiraColors.warning,
          dangerColor: NexiraColors.danger,
          backgroundColor: NexiraColors.background,
          surfaceColor: NexiraColors.surface,
          borderColor: NexiraColors.border,
          textPrimaryColor: NexiraColors.textPrimary,
          textSecondaryColor: NexiraColors.textSecondary,
          radius: NexiraRadius.medium,
          spacing: NexiraSpacing.m,
          shadow: NexiraShadows.cardShadow,
          gradient: NexiraGradients.primary,
          fastAnimationDuration: NexiraAnimations.fast,
          normalAnimationDuration: NexiraAnimations.normal,
          slowAnimationDuration: NexiraAnimations.slow,
          heroAnimationDuration: NexiraAnimations.hero,
        ),
      ],
    );
  }
}

class NexiraThemeData extends ThemeExtension<NexiraThemeData> {
  const NexiraThemeData({
    required this.primaryColor,
    required this.accentColor,
    required this.successColor,
    required this.warningColor,
    required this.dangerColor,
    required this.backgroundColor,
    required this.surfaceColor,
    required this.borderColor,
    required this.textPrimaryColor,
    required this.textSecondaryColor,
    required this.radius,
    required this.spacing,
    required this.shadow,
    required this.gradient,
    required this.fastAnimationDuration,
    required this.normalAnimationDuration,
    required this.slowAnimationDuration,
    required this.heroAnimationDuration,
  });

  final Color primaryColor;
  final Color accentColor;
  final Color successColor;
  final Color warningColor;
  final Color dangerColor;
  final Color backgroundColor;
  final Color surfaceColor;
  final Color borderColor;
  final Color textPrimaryColor;
  final Color textSecondaryColor;
  final BorderRadiusGeometry radius;
  final double spacing;
  final BoxShadow shadow;
  final Gradient gradient;
  final Duration fastAnimationDuration;
  final Duration normalAnimationDuration;
  final Duration slowAnimationDuration;
  final Duration heroAnimationDuration;

  @override
  NexiraThemeData copyWith({
    Color? primaryColor,
    Color? accentColor,
    Color? successColor,
    Color? warningColor,
    Color? dangerColor,
    Color? backgroundColor,
    Color? surfaceColor,
    Color? borderColor,
    Color? textPrimaryColor,
    Color? textSecondaryColor,
    BorderRadiusGeometry? radius,
    double? spacing,
    BoxShadow? shadow,
    Gradient? gradient,
    Duration? fastAnimationDuration,
    Duration? normalAnimationDuration,
    Duration? slowAnimationDuration,
    Duration? heroAnimationDuration,
  }) {
    return NexiraThemeData(
      primaryColor: primaryColor ?? this.primaryColor,
      accentColor: accentColor ?? this.accentColor,
      successColor: successColor ?? this.successColor,
      warningColor: warningColor ?? this.warningColor,
      dangerColor: dangerColor ?? this.dangerColor,
      backgroundColor: backgroundColor ?? this.backgroundColor,
      surfaceColor: surfaceColor ?? this.surfaceColor,
      borderColor: borderColor ?? this.borderColor,
      textPrimaryColor: textPrimaryColor ?? this.textPrimaryColor,
      textSecondaryColor: textSecondaryColor ?? this.textSecondaryColor,
      radius: radius ?? this.radius,
      spacing: spacing ?? this.spacing,
      shadow: shadow ?? this.shadow,
      gradient: gradient ?? this.gradient,
      fastAnimationDuration: fastAnimationDuration ?? this.fastAnimationDuration,
      normalAnimationDuration: normalAnimationDuration ?? this.normalAnimationDuration,
      slowAnimationDuration: slowAnimationDuration ?? this.slowAnimationDuration,
      heroAnimationDuration: heroAnimationDuration ?? this.heroAnimationDuration,
    );
  }

  @override
  NexiraThemeData lerp(ThemeExtension<NexiraThemeData>? other, double t) {
    if (other is! NexiraThemeData) {
      return this;
    }

    return NexiraThemeData(
      primaryColor: Color.lerp(primaryColor, other.primaryColor, t) ?? primaryColor,
      accentColor: Color.lerp(accentColor, other.accentColor, t) ?? accentColor,
      successColor: Color.lerp(successColor, other.successColor, t) ?? successColor,
      warningColor: Color.lerp(warningColor, other.warningColor, t) ?? warningColor,
      dangerColor: Color.lerp(dangerColor, other.dangerColor, t) ?? dangerColor,
      backgroundColor: Color.lerp(backgroundColor, other.backgroundColor, t) ?? backgroundColor,
      surfaceColor: Color.lerp(surfaceColor, other.surfaceColor, t) ?? surfaceColor,
      borderColor: Color.lerp(borderColor, other.borderColor, t) ?? borderColor,
      textPrimaryColor: Color.lerp(textPrimaryColor, other.textPrimaryColor, t) ?? textPrimaryColor,
      textSecondaryColor: Color.lerp(textSecondaryColor, other.textSecondaryColor, t) ?? textSecondaryColor,
      radius: BorderRadius.lerp(radius as BorderRadius?, other.radius as BorderRadius?, t) ?? radius,
      spacing: lerpDouble(spacing, other.spacing, t) ?? spacing,
      shadow: other.shadow,
      gradient: other.gradient,
      fastAnimationDuration: t < 0.5 ? fastAnimationDuration : other.fastAnimationDuration,
      normalAnimationDuration: t < 0.5 ? normalAnimationDuration : other.normalAnimationDuration,
      slowAnimationDuration: t < 0.5 ? slowAnimationDuration : other.slowAnimationDuration,
      heroAnimationDuration: t < 0.5 ? heroAnimationDuration : other.heroAnimationDuration,
    );
  }
}

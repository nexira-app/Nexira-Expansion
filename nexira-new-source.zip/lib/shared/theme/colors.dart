import 'package:flutter/material.dart';

abstract final class NexiraColors {
  static const Color primary = Color(0xFF8B5CF6);
  static const Color accent = Color(0xFF00E5FF);
  static const Color success = Color(0xFF39FF14);
  static const Color warning = Color(0xFFFFC107);
  static const Color danger = Color(0xFFFF2D55);

  static const Color background = Color(0xFF050816);
  static const Color surface = Color(0xFF11182F);
  static const Color surfaceElevated = Color(0xFF1B2747);
  static const Color border = Color(0xFF2A3A5F);

  static const Color textPrimary = Color(0xFFF5F7FF);
  static const Color textSecondary = Color(0xFF94A3B8);
  static const Color textDisabled = Color(0xFF64748B);

  static const Color overlay = Color(0x66050816);
  static const Color shimmer = Color(0x1AFFFFFF);
}

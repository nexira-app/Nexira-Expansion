class GameSessionModel {
  const GameSessionModel({
    required this.id,
    required this.categoryId,
    required this.startTime,
    required this.endTime,
    required this.score,
    required this.correctAnswers,
    required this.wrongAnswers,
    required this.earnedXp,
  });

  final String id;
  final String categoryId;
  final DateTime startTime;
  final DateTime endTime;
  final int score;
  final int correctAnswers;
  final int wrongAnswers;
  final int earnedXp;

  factory GameSessionModel.fromJson(Map<String, dynamic> json) {
    return GameSessionModel(
      id: json['id'] as String,
      categoryId: json['categoryId'] as String,
      startTime: DateTime.parse(json['startTime'] as String),
      endTime: DateTime.parse(json['endTime'] as String),
      score: json['score'] as int,
      correctAnswers: json['correctAnswers'] as int,
      wrongAnswers: json['wrongAnswers'] as int,
      earnedXp: json['earnedXp'] as int,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'categoryId': categoryId,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'score': score,
      'correctAnswers': correctAnswers,
      'wrongAnswers': wrongAnswers,
      'earnedXp': earnedXp,
    };
  }
}

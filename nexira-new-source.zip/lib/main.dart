import 'package:flutter/material.dart';

import 'routes/app_routes.dart';
import 'shared/theme/app_theme.dart';

void main() {
  runApp(const NexiraApp());
}

class NexiraApp extends StatelessWidget {
  const NexiraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NEXIRA',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      initialRoute: AppRoutes.initial,
      onGenerateRoute: AppRoutes.onGenerateRoute,
    );
  }
}

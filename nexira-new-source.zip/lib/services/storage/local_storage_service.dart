import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../core/models/game_session_model.dart';
import '../../core/models/player_profile_model.dart';

abstract class LocalStorageService {
  Future<void> savePlayerProfile(PlayerProfileModel profile);
  Future<PlayerProfileModel?> loadPlayerProfile();
  Future<void> saveGameSession(GameSessionModel session);
  Future<List<GameSessionModel>> loadGameHistory();
}

class SharedPreferencesLocalStorageService implements LocalStorageService {
  SharedPreferencesLocalStorageService(this._prefs);

  final SharedPreferences _prefs;

  static const String _playerProfileKey = 'player_profile';
  static const String _gameHistoryKey = 'game_sessions';

  @override
  Future<void> savePlayerProfile(PlayerProfileModel profile) async {
    final json = jsonEncode(profile.toJson());
    await _prefs.setString(_playerProfileKey, json);
  }

  @override
  Future<PlayerProfileModel?> loadPlayerProfile() async {
    final raw = _prefs.getString(_playerProfileKey);
    if (raw == null || raw.isEmpty) {
      return null;
    }

    final decoded = jsonDecode(raw) as Map<String, dynamic>;
    return PlayerProfileModel.fromJson(decoded);
  }

  @override
  Future<void> saveGameSession(GameSessionModel session) async {
    final history = await loadGameHistory();
    history.add(session);
    final payload = history.map((item) => item.toJson()).toList();
    await _prefs.setString(_gameHistoryKey, jsonEncode(payload));
  }

  @override
  Future<List<GameSessionModel>> loadGameHistory() async {
    final raw = _prefs.getString(_gameHistoryKey);
    if (raw == null || raw.isEmpty) {
      return <GameSessionModel>[];
    }

    final decoded = jsonDecode(raw) as List<dynamic>;
    return decoded
        .map((item) => GameSessionModel.fromJson(item as Map<String, dynamic>))
        .toList();
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:nexira/features/home/home_screen.dart';
import 'package:nexira/pages/leaderboard/leaderboard_screen.dart';
import 'package:nexira/pages/profile/profile_screen.dart';
import 'package:nexira/pages/settings/settings_screen.dart';
import 'package:nexira/shared/theme/app_theme.dart';

void main() {
  testWidgets('Profile screen renders premium player content', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.dark,
        home: const ProfileScreen(),
      ),
    );

    expect(find.text('Guest Player'), findsOneWidget);
    expect(find.text('Create Account'), findsOneWidget);
    expect(find.text('Sign In'), findsOneWidget);
  });

  testWidgets('Leaderboard screen renders local ranking content', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.dark,
        home: const LeaderboardScreen(),
      ),
    );

    expect(find.text('Weekly'), findsOneWidget);
    expect(find.text('All Time'), findsOneWidget);
    expect(find.text('Current Rank'), findsOneWidget);
  });

  testWidgets('Settings screen renders controls', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.dark,
        home: const SettingsScreen(),
      ),
    );

    expect(find.text('Language'), findsOneWidget);
    expect(find.text('Music'), findsOneWidget);
    expect(find.text('App Version'), findsOneWidget);
  });

  testWidgets('Home screen still renders navigation shell', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.dark,
        home: const HomeScreen(),
      ),
    );

    expect(find.text('Challenge Modes'), findsOneWidget);
  });
}
